# Viltools Trading Bot

A static, single-page HTML website packaged for GitHub Pages.

## Publish with GitHub Pages

1. Create a new repository on GitHub.
2. Upload the contents of this folder (`index.html`, `README.md`, and `.nojekyll`) to the repository's root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for GitHub Pages to finish deploying. Your site URL will appear in the Pages settings.

## Notes

- The site is a static HTML/CSS/JavaScript app; no build step is required for GitHub Pages.
- It loads Google Fonts and Lightweight Charts from third-party CDNs and requests market data from external APIs, so those services need to be reachable in the visitor's browser.
- Browser API/CORS limits or changes to third-party services may affect live market features.
- Do not publish private API keys, wallet seed phrases, or private keys. Any key entered into the website's browser UI should be treated as exposed to that browser session.
- This package does not provide a server-side backend. Review and test wallet connections and any real-money transaction flow carefully before making the site public.
